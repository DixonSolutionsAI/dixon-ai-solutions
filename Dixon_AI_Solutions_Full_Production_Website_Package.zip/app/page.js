
export default function Home(){
return <main style={{fontFamily:'Arial',background:'#020617',color:'white',padding:'20px'}}>
<h1>Dixon AI Solutions LLC</h1>
<p>AI Receptionists • Lead Qualification • CRM Automation • Appointment Booking</p>
<h2>Services</h2><ul><li>AI Receptionist</li><li>Appointment Booking</li><li>CRM Automation</li></ul>
<h2>Pricing</h2><ul><li>Starter $297/mo</li><li>Growth $697/mo</li><li>Professional $1,197/mo</li><li>Enterprise Custom</li></ul>
<h2>Why Choose Us</h2><p>Lead response in under 60 seconds.</p>
<h2>ROI Calculator</h2><p>Demonstration section ready for enhancement.</p>
<h2>Testimonials</h2><p>Placeholder testimonials included.</p>
<h2>FAQ</h2><p>Setup times, CRM integrations, and AI workflow answers.</p>
<h2>Book a Strategy Session</h2><p>Connect Calendly here.</p>
<h2>Stripe Checkout</h2><p>Connect payment links here.</p>
<h2>AI Chatbot</h2><p>Embed GoHighLevel, Vapi, or Retell AI widget.</p>
</main>
}
